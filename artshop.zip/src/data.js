export const products =
{
    "clothing": [
        {
            name: "Jerk Chicken",
            price: 13.38,
            count: 1,
            image: 'jerk-chicken'
        },
        {
            name: "Fowl Ball",
            price: 15.74,
            count: 0,
            image: 'fowl-ball'
        },
        {
            name: "Johann",
            price: 15.74,
            count: 2,
            image: 'johann'
        },
        {
            name: "Niels Boar ",
            price: 15.74,
            count: 0,
            image: 'niels-boar'
        },
        {
            name: "Johanns",
            price: 13.38,
            count: 0,
            image: 'johanns'
        },
        {
            name: "Chicken",
            price: 15.74,
            count: 1,
            image: 'chicken'
        }
    ],
    "t-shirts": [
        {
            name: "Hogking",
            price: 15.74,
            count: 2,
            image: 'hogking'
        },
        {
            name: "Bass Player",
            price: 13.74,
            count: 0,
            image: 'bass-player'
        },
        {
            name: "Einswine",
            price: 13.74,
            count: 1,
            image: 'einswine'
        },
        {
            name: "Jerk Chicken",
            price: 13.38,
            count: 1,
            image: 'jerk-chicken'
        },
        {
            name: "Fowl Ball",
            price: 15.74,
            count: 0,
            image: 'fowl-ball'
        },
        {
            name: "Johann",
            price: 15.74,
            count: 2,
            image: 'johann'
        },
    ],
    "digital art": [
        {
            name: "Niels Boar ",
            price: 15.74,
            count: 0,
            image: 'niels-boar'
        },
        {
            name: "Johanns",
            price: 13.38,
            count: 0,
            image: 'johanns'
        },
        {
            name: "Chicken",
            price: 15.74,
            count: 1,
            image: 'chicken'
        },
        {
            name: "Jerk Chicken",
            price: 13.38,
            count: 1,
            image: 'jerk-chicken'
        },
        {
            name: "Fowl Ball",
            price: 15.74,
            count: 0,
            image: 'fowl-ball'
        },
        {
            name: "Johann",
            price: 15.74,
            count: 2,
            image: 'johann'
        },
    ]


}